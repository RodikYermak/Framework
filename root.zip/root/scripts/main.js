$(document).ready(function() {
  $('.hide').click(function() {
    $(this).hide();
  });
});
